#ifndef Top_HW_PLATFORM_H_
#define Top_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Mon Nov 11 12:25:04 2013
*
*Memory map specification for peripherals in Top
*/

/*-----------------------------------------------------------------------------
* SDR_MSS_0 subsystem memory map
* Master(s) for this subsystem: SDR_MSS_0 
*---------------------------------------------------------------------------*/
#define MBUS_APB_0                      0x40050000U


#endif /* Top_HW_PLATFORM_H_*/
