#ifndef TOPLEVEL_HW_PLATFORM_H_
#define TOPLEVEL_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Actel SmartDesign  Sun Jan 20 16:23:46 2013
*
*Memory map specification for peripherals in TOPLEVEL
*/

/*-----------------------------------------------------------------------------
* MSS_CORE2_0 subsystem memory map
* Master(s) for this subsystem: MSS_CORE2_0 
*---------------------------------------------------------------------------*/
#define SIMPLE_LAYER_CONTROLLER_0       0x40060000U
#define SIMPLE_LAYER_CONTROLLER2_0      0x40070000U
#define SIMPLE_LAYER_CONTROLLER3_0      0x40080000U


#endif /* TOPLEVEL_HW_PLATFORM_H_*/
